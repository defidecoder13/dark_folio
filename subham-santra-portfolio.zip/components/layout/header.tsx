'use client';

import Link from 'next/link';

export function Header() {
  return (
    <header className="fixed top-0 w-full bg-background/80 backdrop-blur-md border-b border-foreground/5 z-50">
      <nav className="max-w-7xl mx-auto px-6 md:px-8 py-5 flex items-center justify-between">
        {/* Logo */}
        <Link href="/" className="text-2xl font-bold tracking-tight">
          SS
        </Link>

        {/* Navigation Links */}
        <div className="hidden md:flex items-center gap-8">
          <a href="#about" className="text-sm font-medium text-foreground/70 hover:text-foreground transition-colors">
            About
          </a>
          <a href="#work" className="text-sm font-medium text-foreground/70 hover:text-foreground transition-colors">
            Work
          </a>
          <a href="#services" className="text-sm font-medium text-foreground/70 hover:text-foreground transition-colors">
            Services
          </a>
          <a href="#contact" className="text-sm font-medium text-foreground/70 hover:text-foreground transition-colors">
            Contact
          </a>
        </div>

        {/* CTA Button */}
        <a
          href="#contact"
          className="inline-flex items-center gap-2 px-5 py-2.5 text-sm font-medium bg-foreground text-background rounded-full hover:bg-foreground/90 transition-all"
        >
          Let&apos;s Talk
        </a>
      </nav>
    </header>
  );
}
