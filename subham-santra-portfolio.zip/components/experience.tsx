"use client";

import { useState } from "react";
import { ChevronDown } from "lucide-react";

export function Experience() {
  const [expandedIndex, setExpandedIndex] = useState(0);

  const experiences = [
    {
      title: "Senior Full Stack Developer",
      company: "TechCorp Solutions",
      period: "2023 - Present",
      description: "Leading the development of scalable web applications using Next.js and Node.js. Mentoring junior developers and architecting solutions for high-traffic applications.",
      achievements: [
        "Increased application performance by 40% through optimization",
        "Led migration from Vue to React resulting in 30% better code reusability",
        "Mentored 5 junior developers"
      ]
    },
    {
      title: "Full Stack Developer",
      company: "StartupHub Inc.",
      period: "2021 - 2023",
      description: "Developed and maintained multiple full-stack applications for various clients. Implemented real-time features and optimized database queries.",
      achievements: [
        "Built real-time chat system using Socket.io",
        "Reduced API response time by 50%",
        "Launched 12+ successful projects"
      ]
    },
    {
      title: "Frontend Developer",
      company: "Digital Agency Pro",
      period: "2020 - 2021",
      description: "Created responsive and interactive user interfaces using React and modern CSS. Collaborated with designers and backend developers.",
      achievements: [
        "Won Best UI/UX Award for 2021",
        "Improved website load time by 35%",
        "Developed reusable component library"
      ]
    },
    {
      title: "Junior Web Developer",
      company: "WebDev Studios",
      period: "2019 - 2020",
      description: "Started career building static websites and basic dynamic applications. Learned fundamentals of web development and best practices.",
      achievements: [
        "Completed 25+ client projects",
        "Mastered JavaScript and React basics",
        "Contributed to open-source projects"
      ]
    }
  ];

  return (
    <section id="experience" className="py-20 md:py-32 relative overflow-hidden">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/2 right-0 w-96 h-96 bg-primary/5 rounded-full blur-3xl"></div>
      </div>

      <div className="container max-w-7xl mx-auto px-4 md:px-6 relative z-10">
        {/* Section Header */}
        <div className="mb-16 md:mb-24">
          <div className="inline-block mb-4">
            <span className="px-4 py-2 bg-primary/10 text-primary border border-primary/30 rounded-full text-sm font-semibold">Work Experience</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
            Career Journey
          </h2>
          <p className="text-lg text-foreground/70 max-w-2xl">
            A journey of growth, learning, and building impactful solutions
          </p>
        </div>

        {/* Timeline */}
        <div className="space-y-4">
          {experiences.map((exp, idx) => (
            <div key={idx} className="group relative">
              {/* Timeline connector line */}
              {idx !== experiences.length - 1 && (
                <div className="absolute left-8 top-20 bottom-0 w-px bg-gradient-to-b from-primary/50 to-transparent"></div>
              )}

              {/* Card */}
              <div
                onClick={() => setExpandedIndex(expandedIndex === idx ? -1 : idx)}
                className="relative bg-surface/50 backdrop-blur-md border border-primary/20 rounded-xl p-6 md:p-8 hover:border-primary/60 hover:bg-surface/70 transition-all cursor-pointer transform hover:translate-x-2"
              >
                {/* Timeline dot */}
                <div className="absolute -left-12 top-8 w-6 h-6 bg-primary rounded-full border-4 border-background shadow-lg shadow-primary/30"></div>

                {/* Header */}
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <h3 className="text-xl md:text-2xl font-bold text-foreground group-hover:text-primary transition-colors duration-300">
                      {exp.title}
                    </h3>
                    <p className="text-primary font-semibold text-sm md:text-base mt-2">{exp.company}</p>
                    <p className="text-foreground/60 text-sm mt-1">{exp.period}</p>
                  </div>
                  <ChevronDown
                    className={`w-5 h-5 text-primary transition-transform duration-300 flex-shrink-0 ${
                      expandedIndex === idx ? "rotate-180" : ""
                    }`}
                  />
                </div>

                <p className="text-foreground/80 text-base leading-relaxed mb-2">{exp.description}</p>

                {/* Expandable content */}
                {expandedIndex === idx && (
                  <div className="mt-6 space-y-4 border-t border-primary/20 pt-6 animate-fade-in">
                    <div>
                      <h4 className="text-sm font-semibold text-primary mb-3">Key Achievements</h4>
                      <ul className="space-y-2">
                        {exp.achievements.map((achievement, aidx) => (
                          <li key={aidx} className="flex gap-3 items-start text-sm text-foreground/80">
                            <span className="text-primary mt-1">✓</span>
                            <span>{achievement}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div>
                      <h4 className="text-sm font-semibold text-primary mb-3">Technologies Used</h4>
                      <div className="flex flex-wrap gap-2">
                        {["React", "Node.js", "TypeScript", "PostgreSQL"].map((tech) => (
                          <span
                            key={tech}
                            className="px-3 py-1 bg-primary/15 text-primary text-xs font-medium rounded-full border border-primary/30"
                          >
                            {tech}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>


      </div>
    </section>
  );
}
