"use client";

import Image from "next/image";
import { useState, useEffect } from "react";
import { ArrowRight, Code2 } from "lucide-react";

export function Hero() {
  const [displayedCode, setDisplayedCode] = useState("");
  const codeSnippet = `const subham = {
  role: "Full Stack Developer",
  passion: "Building amazing web experiences",
  technologies: ["React", "Next.js", "TypeScript", "Node.js"],
  status: "Open to opportunities 🚀"
};`;

  useEffect(() => {
    let currentIndex = 0;
    const interval = setInterval(() => {
      if (currentIndex <= codeSnippet.length) {
        setDisplayedCode(codeSnippet.substring(0, currentIndex));
        currentIndex++;
      } else {
        clearInterval(interval);
      }
    }, 30);

    return () => clearInterval(interval);
  }, []);

  return (
    <section className="min-h-screen flex items-center justify-center relative overflow-hidden pt-20 md:pt-0">
      {/* Animated background gradient */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 right-0 w-96 h-96 bg-primary/10 rounded-full blur-3xl opacity-30 animate-pulse"></div>
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-secondary/10 rounded-full blur-3xl opacity-30 animate-pulse" style={{ animationDelay: "1s" }}></div>
        <div className="absolute top-1/2 left-1/2 w-96 h-96 bg-accent/10 rounded-full blur-3xl opacity-20 animate-pulse" style={{ animationDelay: "2s" }}></div>
      </div>

      <div className="container max-w-7xl mx-auto px-4 md:px-6 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12 items-center">
          {/* Left side - Code Animation */}
          <div className="animate-fade-in order-2 md:order-1">
            <div className="group relative">
              {/* Code block background */}
              <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-secondary/20 rounded-xl blur-xl group-hover:blur-2xl transition-all duration-300 opacity-50"></div>
              
              {/* Code block */}
              <div className="relative bg-surface/80 backdrop-blur-sm border border-primary/30 rounded-xl p-6 md:p-8 font-mono text-xs md:text-sm overflow-hidden">
                {/* Glow effect */}
                <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-primary to-transparent opacity-50"></div>
                
                {/* Code content */}
                <div className="space-y-1">
                  {displayedCode.split("\n").map((line, idx) => (
                    <div key={idx} className="flex items-center">
                      <span className="text-muted/50 mr-4 select-none">{String(idx + 1).padStart(2, "0")}</span>
                      <code className="text-foreground/90 whitespace-pre-wrap break-words">
                        {line === "" ? "\n" : line}
                      </code>
                    </div>
                  ))}
                  {displayedCode.length < codeSnippet.length && (
                    <div className="flex items-center">
                      <span className="text-muted/50 mr-4 select-none">
                        {String(displayedCode.split("\n").length + 1).padStart(2, "0")}
                      </span>
                      <span className="text-primary animate-blink-cursor">▍</span>
                    </div>
                  )}
                </div>

                {/* Copy button hint */}
                <div className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity">
                  <Code2 className="w-5 h-5 text-primary/60" />
                </div>
              </div>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-4 mt-8">
              {[
                { label: "Projects", value: "20+" },
                { label: "Years Exp.", value: "5+" },
                { label: "Clients", value: "30+" }
              ].map((stat, idx) => (
                <div
                  key={idx}
                  className="bg-surface/40 backdrop-blur-sm border border-primary/20 rounded-lg p-4 text-center hover:border-primary/60 transition-colors"
                  style={{ animationDelay: `${idx * 0.2}s` }}
                >
                  <p className="text-2xl md:text-3xl font-bold text-primary">{stat.value}</p>
                  <p className="text-xs md:text-sm text-muted mt-1">{stat.label}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Right side - Profile */}
          <div className="animate-slide-in-left order-1 md:order-2 flex flex-col items-center md:items-start">
            {/* Profile Image with Cinematic Blend */}
            <div className="relative mb-8 animate-float w-72 md:w-80">
              {/* Outer glow ring */}
              <div className="absolute -inset-4 bg-gradient-to-br from-primary via-secondary to-accent rounded-3xl blur-3xl opacity-30 animate-pulse"></div>
              
              {/* Middle gradient frame */}
              <div className="absolute inset-0 bg-gradient-to-br from-primary/40 via-secondary/30 to-accent/20 rounded-3xl p-1 blur-sm opacity-80"></div>
              
              {/* Image container with cinematic bottom fade */}
              <div className="relative w-full aspect-[3/4] rounded-3xl overflow-hidden shadow-2xl">
                {/* Gradient border effect */}
                <div className="absolute inset-0 bg-gradient-to-br from-primary/50 to-secondary/50 rounded-3xl"></div>
                
                {/* Image with object-fit */}
                <div className="absolute inset-1 rounded-3xl overflow-hidden bg-background">
                  <Image
                    src="/subham-profile.png"
                    alt="Subham Santra"
                    fill
                    className="object-cover object-center"
                    priority
                  />
                  
                  {/* Cinematic bottom fade overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-background via-background/50 to-transparent opacity-60 rounded-3xl"></div>
                  
                  {/* Top light effect */}
                  <div className="absolute top-0 left-0 right-0 h-32 bg-gradient-to-b from-primary/20 to-transparent opacity-40 rounded-t-3xl"></div>
                </div>
              </div>
            </div>

            {/* Text Content */}
            <div className="text-center md:text-left max-w-md">
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-2">
                <span className="text-foreground">Subham</span>
                <br />
                <span className="bg-gradient-to-r from-primary via-secondary to-accent bg-clip-text text-transparent">Santra</span>
              </h1>
              
              <p className="text-primary text-lg md:text-xl font-semibold mb-4">Full Stack Developer</p>
              
              <p className="text-muted/90 text-base md:text-lg leading-relaxed mb-8">
                Crafting beautiful, performant, and user-centric digital experiences. Specializing in modern web technologies and innovative problem-solving.
              </p>

              {/* CTA Buttons */}
              <div className="flex flex-col sm:flex-row gap-4 justify-center md:justify-start">
                <button className="group relative px-8 py-3 bg-gradient-to-r from-primary to-primary/80 text-background font-semibold rounded-lg overflow-hidden hover:shadow-lg hover:shadow-primary/50 transition-all">
                  <span className="relative z-10 flex items-center gap-2">
                    View My Work
                    <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </span>
                  <div className="absolute inset-0 bg-gradient-to-r from-primary/60 to-secondary/60 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                </button>
                
                <button className="px-8 py-3 border-2 border-primary text-primary font-semibold rounded-lg hover:bg-primary/10 transition-colors">
                  Get In Touch
                </button>
              </div>

              {/* Social Links */}
              <div className="flex gap-6 mt-8 justify-center md:justify-start">
                {[
                  { icon: "GitHub", link: "#" },
                  { icon: "LinkedIn", link: "#" },
                  { icon: "Twitter", link: "#" }
                ].map((social) => (
                  <a
                    key={social.icon}
                    href={social.link}
                    className="w-10 h-10 rounded-full border border-primary/30 flex items-center justify-center text-muted hover:text-primary hover:border-primary hover:bg-primary/10 transition-all"
                    aria-label={social.icon}
                  >
                    <span className="text-xs font-bold">{social.icon[0]}</span>
                  </a>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2">
        <div className="flex flex-col items-center gap-2 animate-bounce">
          <span className="text-xs text-muted">Scroll to explore</span>
          <svg className="w-6 h-6 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
          </svg>
        </div>
      </div>
    </section>
  );
}
