import { Code2, Zap, Target } from "lucide-react";

export function About() {
  const highlights = [
    {
      icon: Code2,
      title: "Clean Code",
      description: "Writing maintainable, scalable, and well-documented code following industry best practices."
    },
    {
      icon: Zap,
      title: "Performance",
      description: "Optimizing applications for speed and efficiency without compromising on functionality."
    },
    {
      icon: Target,
      title: "User Focus",
      description: "Designing solutions that prioritize user experience and solve real-world problems."
    }
  ];

  return (
    <section id="about" className="py-20 md:py-32 relative overflow-hidden">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/3 left-0 w-72 h-72 bg-secondary/5 rounded-full blur-3xl"></div>
      </div>

      <div className="container max-w-7xl mx-auto px-4 md:px-6 relative z-10">
        {/* Section Header */}
        <div className="mb-16 md:mb-24">
          <h2 className="text-3xl md:text-5xl font-bold mb-4">
            <span className="text-foreground">About </span>
            <span className="bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">Me</span>
          </h2>
          <p className="text-muted max-w-2xl">
            I&apos;m a passionate full-stack developer with a keen eye for design and a love for solving complex problems through elegant code.
          </p>
        </div>

        {/* Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12 md:gap-16 mb-16">
          {/* Text Content */}
          <div className="lg:col-span-2 space-y-6">
            <div>
              <h3 className="text-2xl font-semibold text-foreground mb-4">Experience & Expertise</h3>
              <p className="text-foreground/80 text-base leading-relaxed">
                With over 5 years of experience in full-stack development, I&apos;ve had the pleasure of working with startups and established companies to build digital solutions that make a real impact.
              </p>
            </div>
            
            <div>
              <h3 className="text-xl font-semibold text-foreground mb-3">Technical Specialization</h3>
              <p className="text-foreground/80 text-base leading-relaxed">
                I specialize in building modern web applications using React, Next.js, Node.js, and TypeScript. My approach combines technical expertise with a deep understanding of user needs to create solutions that are both powerful and intuitive.
              </p>
            </div>

            <div>
              <h3 className="text-xl font-semibold text-foreground mb-3">Continuous Learning</h3>
              <p className="text-foreground/80 text-base leading-relaxed">
                When I&apos;m not coding, you can find me exploring new technologies, contributing to open-source projects, or sharing knowledge with the developer community.
              </p>
            </div>

            <div className="pt-6">
              <button className="group relative inline-flex items-center gap-2 px-6 py-3 bg-surface border border-primary/30 text-foreground font-semibold rounded-lg hover:border-primary/60 hover:bg-surface/80 transition-all duration-300">
                <span>Download Resume</span>
                <svg className="w-4 h-4 group-hover:translate-y-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M9 19l3 3m0 0l3-3m-3 3V10" />
                </svg>
              </button>
            </div>
          </div>

          {/* Highlights Grid */}
          <div className="space-y-4">
            {highlights.map((item, idx) => {
              const Icon = item.icon;
              return (
                <div
                  key={idx}
                  className="group bg-surface/50 backdrop-blur-md border border-primary/20 rounded-xl p-5 hover:border-primary/60 hover:bg-surface/80 transition-all duration-300 hover:shadow-lg hover:shadow-primary/10"
                >
                  <div className="flex gap-3 mb-2">
                    <div className="p-2.5 bg-primary/10 rounded-lg group-hover:bg-primary/20 transition-colors flex-shrink-0">
                      <Icon className="w-5 h-5 text-primary" />
                    </div>
                  </div>
                  <h3 className="text-base font-semibold text-foreground mb-2">{item.title}</h3>
                  <p className="text-sm text-foreground/70 leading-relaxed">{item.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
