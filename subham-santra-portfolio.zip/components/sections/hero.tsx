'use client';

import Image from 'next/image';
import { ArrowRight } from 'lucide-react';
import { useState } from 'react';

const codeParticles = ['const', '{', 'name', '}', '=', 'React', 'function', 'import', 'export', 'return', 'JSX', 'props', 'state', 'hooks'];

export function HeroSection() {
  const [particles, setParticles] = useState<Array<{ id: string; x: number; y: number }>>([]);

  const handleImageHover = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    // Create particle burst
    const newParticles = Array.from({ length: 8 }).map((_, i) => ({
      id: `${Date.now()}-${i}`,
      x,
      y,
    }));

    setParticles((prev) => [...prev, ...newParticles]);

    // Remove particles after animation
    setTimeout(() => {
      setParticles((prev) => prev.filter((p) => !newParticles.some((np) => np.id === p.id)));
    }, 800);
  };

  return (
    <section className="min-h-screen pt-32 pb-20 md:pb-32 flex items-center">
      <div className="max-w-7xl mx-auto px-6 md:px-8 w-full">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 md:gap-16 items-center">
          {/* Left: Text Content */}
          <div className="space-y-8">
            <div className="space-y-4">
              <p className="text-sm md:text-base font-medium text-foreground/60 uppercase tracking-wider">
                Full Stack Developer
              </p>
              <h1 className="text-5xl md:text-7xl font-bold leading-tight tracking-tight">
                Subham
                <br />
                Santra
              </h1>
              <p className="text-lg md:text-xl text-foreground/70 leading-relaxed max-w-lg">
                Crafting beautiful, performant digital experiences with modern web technologies. Specialized in React, Next.js, and full-stack development.
              </p>
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 pt-4">
              <a
                href="#work"
                className="inline-flex items-center justify-center gap-3 px-8 py-4 bg-foreground text-background font-medium rounded-lg hover:bg-foreground/90 transition-all group"
              >
                View My Work
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </a>
              <a
                href="#contact"
                className="inline-flex items-center justify-center gap-3 px-8 py-4 border border-foreground/20 text-foreground font-medium rounded-lg hover:border-foreground/40 hover:bg-foreground/5 transition-all"
              >
                Get In Touch
              </a>
            </div>

            {/* Stats */}
            <div className="flex gap-8 md:gap-12 pt-8 border-t border-foreground/10">
              <div>
                <p className="text-3xl md:text-4xl font-bold">20+</p>
                <p className="text-sm text-foreground/60 mt-2">Projects Completed</p>
              </div>
              <div>
                <p className="text-3xl md:text-4xl font-bold">5+</p>
                <p className="text-sm text-foreground/60 mt-2">Years Experience</p>
              </div>
              <div>
                <p className="text-3xl md:text-4xl font-bold">30+</p>
                <p className="text-sm text-foreground/60 mt-2">Happy Clients</p>
              </div>
            </div>
          </div>

          {/* Right: Profile Image */}
          <div className="relative h-96 md:h-full md:min-h-screen -mx-6 md:mx-0 flex items-center justify-center md:justify-end">
            {/* Interactive image container */}
            <div
              onMouseMove={handleImageHover}
              className="relative w-72 h-96 md:w-full md:h-full max-w-md md:max-w-none group cursor-crosshair overflow-hidden"
            >
              {/* Animated background gradient */}
              <div className="absolute inset-0 bg-gradient-to-br from-white/5 via-white/10 to-white/5 rounded-3xl md:rounded-none opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>

              {/* Glitch effect overlay on hover */}
              <div className="absolute inset-0 group-hover:animate-glitch rounded-3xl md:rounded-none pointer-events-none opacity-0 group-hover:opacity-20"></div>

              {/* Main image */}
              <div className="relative w-full h-full">
                <Image
                  src="/profile.png"
                  alt="Subham Santra"
                  fill
                  className="object-contain md:object-cover md:object-center transition-all duration-300 group-hover:saturate-110"
                  priority
                />

                {/* Cinematic fade overlays */}
                <div className="absolute inset-0 bg-gradient-to-t from-background via-background/30 to-transparent rounded-3xl md:rounded-none"></div>
                <div className="absolute inset-0 bg-gradient-to-r from-background via-transparent to-transparent rounded-3xl md:rounded-none opacity-50 group-hover:opacity-0 transition-opacity duration-500"></div>

                {/* Code particle burst container */}
                <div className="absolute inset-0 pointer-events-none">
                  {particles.map((particle, idx) => (
                    <div
                      key={particle.id}
                      className="absolute text-xs font-mono text-white/80 animate-code-burst whitespace-nowrap"
                      style={{
                        left: `${particle.x}px`,
                        top: `${particle.y}px`,
                        '--tx': `${(Math.random() - 0.5) * 200}px`,
                        '--ty': `${(Math.random() - 0.5) * 200}px`,
                      } as React.CSSProperties & { '--tx': string; '--ty': string }}
                    >
                      {codeParticles[idx % codeParticles.length]}
                    </div>
                  ))}
                </div>
              </div>

              {/* Hover label */}
              <div className="absolute bottom-6 left-6 text-xs text-white/60 font-mono opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                {'<code />'} destructure
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
