'use client';

export function AboutSection() {
  return (
    <section id="about" className="py-20 md:py-32 border-t border-foreground/5">
      <div className="max-w-7xl mx-auto px-6 md:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 md:gap-20">
          {/* Left: Heading */}
          <div>
            <p className="text-sm font-medium text-foreground/60 uppercase tracking-wider mb-4">About</p>
            <h2 className="text-4xl md:text-5xl font-bold leading-tight">
              Passionate about building beautiful digital products
            </h2>
          </div>

          {/* Right: Content */}
          <div className="space-y-6">
            <p className="text-base md:text-lg text-foreground/70 leading-relaxed">
              With 5+ years of experience in full-stack development, I specialize in crafting digital solutions that combine elegant design with robust functionality. I work with startups and established companies to bring their visions to life.
            </p>
            <p className="text-base md:text-lg text-foreground/70 leading-relaxed">
              My expertise spans React, Next.js, Node.js, TypeScript, and modern web technologies. I approach every project with a focus on performance, accessibility, and user experience.
            </p>
            <p className="text-base md:text-lg text-foreground/70 leading-relaxed">
              When I&apos;m not coding, I&apos;m exploring new technologies, contributing to open-source, or sharing knowledge with the developer community.
            </p>

            {/* Tech Stack */}
            <div className="pt-8">
              <p className="text-sm font-medium text-foreground/60 uppercase tracking-wider mb-4">Tech Stack</p>
              <div className="flex flex-wrap gap-3">
                {['React', 'Next.js', 'TypeScript', 'Node.js', 'PostgreSQL', 'Tailwind CSS'].map((tech) => (
                  <span
                    key={tech}
                    className="px-4 py-2 bg-foreground/5 text-foreground/80 text-sm font-medium rounded-full border border-foreground/10 hover:border-foreground/20 transition-colors"
                  >
                    {tech}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
