'use client';

import { useState } from 'react';

const skillCategories = [
  {
    name: 'Frontend',
    skills: [
      { name: 'React', icon: '⚛️', color: 'from-blue-400 to-cyan-400' },
      { name: 'Next.js', icon: '▲', color: 'from-gray-200 to-white' },
      { name: 'TypeScript', icon: 'TS', color: 'from-blue-500 to-blue-600' },
      { name: 'Tailwind CSS', icon: '🎨', color: 'from-cyan-400 to-blue-500' },
      { name: 'Vue.js', icon: '◆', color: 'from-green-400 to-emerald-500' },
      { name: 'JavaScript', icon: 'JS', color: 'from-yellow-400 to-yellow-600' },
    ],
  },
  {
    name: 'Backend',
    skills: [
      { name: 'Node.js', icon: '⬢', color: 'from-green-500 to-emerald-600' },
      { name: 'PostgreSQL', icon: '🗄️', color: 'from-blue-600 to-blue-800' },
      { name: 'MongoDB', icon: '🍃', color: 'from-green-600 to-green-800' },
      { name: 'REST APIs', icon: '🔌', color: 'from-orange-400 to-red-500' },
      { name: 'GraphQL', icon: '#', color: 'from-pink-500 to-rose-600' },
      { name: 'Firebase', icon: '🔥', color: 'from-yellow-500 to-orange-600' },
    ],
  },
  {
    name: 'Tools',
    skills: [
      { name: 'Git', icon: '⎇', color: 'from-red-600 to-orange-600' },
      { name: 'Docker', icon: '📦', color: 'from-blue-500 to-cyan-600' },
      { name: 'AWS', icon: '☁️', color: 'from-orange-500 to-yellow-600' },
      { name: 'Vercel', icon: '▲', color: 'from-gray-800 to-black' },
      { name: 'GitHub', icon: '🐙', color: 'from-gray-700 to-gray-900' },
      { name: 'VS Code', icon: '❋', color: 'from-blue-600 to-cyan-500' },
    ],
  },
];

export function SkillsSection() {
  const [activeCategory, setActiveCategory] = useState(0);
  const [hoveredSkill, setHoveredSkill] = useState<string | null>(null);

  return (
    <section id="skills" className="py-24 md:py-32 relative overflow-hidden">
      {/* Animated background elements */}
      <div className="absolute top-20 right-10 w-72 h-72 bg-white/5 rounded-full blur-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-1000"></div>
      <div className="absolute bottom-20 left-10 w-96 h-96 bg-white/3 rounded-full blur-3xl"></div>

      <div className="max-w-7xl mx-auto px-6 md:px-8 relative z-10">
        {/* Header */}
        <div className="text-center mb-16 md:mb-24 space-y-4">
          <h2 className="text-5xl md:text-6xl font-bold tracking-tight">
            Technical <span className="text-foreground/60">Arsenal</span>
          </h2>
          <p className="text-lg text-foreground/60 max-w-2xl mx-auto">
            A comprehensive set of tools and technologies I&apos;ve mastered to build exceptional digital products.
          </p>
        </div>

        {/* Category Tabs */}
        <div className="flex gap-3 md:gap-4 justify-center mb-16 flex-wrap">
          {skillCategories.map((category, idx) => (
            <button
              key={idx}
              onClick={() => setActiveCategory(idx)}
              className={`px-6 md:px-8 py-3 rounded-lg font-medium text-sm md:text-base transition-all duration-300 ${
                activeCategory === idx
                  ? 'bg-foreground text-background scale-105'
                  : 'bg-foreground/10 text-foreground hover:bg-foreground/20'
              }`}
            >
              {category.name}
            </button>
          ))}
        </div>

        {/* Skills Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 md:gap-6">
          {skillCategories[activeCategory].skills.map((skill, idx) => (
            <div
              key={skill.name}
              onMouseEnter={() => setHoveredSkill(skill.name)}
              onMouseLeave={() => setHoveredSkill(null)}
              className="group relative"
              style={{
                animation: `float-up 0.5s ease-out ${idx * 0.05}s both`,
              }}
            >
              {/* Animated card */}
              <div
                className={`relative h-48 rounded-xl p-6 flex flex-col items-center justify-center text-center cursor-pointer transition-all duration-300 overflow-hidden
                  ${hoveredSkill === skill.name ? 'scale-110 shadow-2xl' : 'hover:shadow-lg'}
                  bg-gradient-to-br ${skill.color} opacity-20 hover:opacity-30
                `}
              >
                {/* Shimmer effect on hover */}
                {hoveredSkill === skill.name && (
                  <div className="absolute inset-0 animate-shimmer bg-white/10"></div>
                )}

                {/* Content */}
                <div className="relative z-10 space-y-3">
                  {/* Icon with 3D rotation */}
                  <div
                    className={`text-5xl md:text-6xl transition-transform duration-300 ${
                      hoveredSkill === skill.name ? 'animate-spin-3d' : ''
                    }`}
                    style={{
                      transformStyle: 'preserve-3d',
                    }}
                  >
                    {skill.icon}
                  </div>

                  {/* Name */}
                  <h3 className="font-semibold text-sm md:text-base text-foreground">
                    {skill.name}
                  </h3>

                  {/* Hover indicator */}
                  {hoveredSkill === skill.name && (
                    <div className="text-xs text-foreground/70 font-mono animate-float">
                      {'→ expert'}
                    </div>
                  )}
                </div>

                {/* Border glow effect */}
                <div
                  className={`absolute inset-0 rounded-xl border-2 transition-all duration-300 pointer-events-none
                    ${hoveredSkill === skill.name ? `border-white/40 shadow-lg shadow-white/10 animate-pulse-glow` : 'border-white/10'}
                  `}
                ></div>
              </div>
            </div>
          ))}
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-8 mt-24 pt-24 border-t border-foreground/10">
          <div className="text-center space-y-2">
            <p className="text-3xl md:text-4xl font-bold animate-pulse-glow inline-block">18+</p>
            <p className="text-sm text-foreground/60">Core Technologies</p>
          </div>
          <div className="text-center space-y-2">
            <p className="text-3xl md:text-4xl font-bold animate-pulse-glow inline-block">5+</p>
            <p className="text-sm text-foreground/60">Years Expertise</p>
          </div>
          <div className="text-center space-y-2">
            <p className="text-3xl md:text-4xl font-bold animate-pulse-glow inline-block">100%</p>
            <p className="text-sm text-foreground/60">Dedication</p>
          </div>
        </div>
      </div>
    </section>
  );
}
