'use client';

import { Mail, LinkIcon, GitBranch, Share2 } from 'lucide-react';

export function ContactSection() {
  return (
    <section id="contact" className="py-20 md:py-32 border-t border-foreground/5">
      <div className="max-w-7xl mx-auto px-6 md:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 md:gap-20">
          {/* Left: CTA */}
          <div>
            <p className="text-sm font-medium text-foreground/60 uppercase tracking-wider mb-4">Contact</p>
            <h2 className="text-4xl md:text-5xl font-bold leading-tight">
              Let&apos;s create something amazing together
            </h2>
          </div>

          {/* Right: Contact Details */}
          <div className="space-y-8">
            {/* Email */}
            <div>
              <p className="text-sm font-medium text-foreground/60 uppercase tracking-wider mb-3">Email</p>
              <a
                href="mailto:subham@example.com"
                className="text-xl md:text-2xl font-bold hover:text-foreground/70 transition-colors break-all"
              >
                subham@example.com
              </a>
            </div>

            {/* Social Links */}
            <div>
              <p className="text-sm font-medium text-foreground/60 uppercase tracking-wider mb-4">Connect</p>
              <div className="flex gap-4">
                <a
                  href="https://github.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-12 h-12 rounded-xl bg-foreground/5 border border-foreground/10 flex items-center justify-center hover:border-foreground/20 hover:bg-foreground/10 transition-all group"
                >
                  <GitBranch className="w-5 h-5 text-foreground group-hover:text-foreground transition-colors" />
                </a>
                <a
                  href="https://linkedin.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-12 h-12 rounded-xl bg-foreground/5 border border-foreground/10 flex items-center justify-center hover:border-foreground/20 hover:bg-foreground/10 transition-all group"
                >
                  <LinkIcon className="w-5 h-5 text-foreground group-hover:text-foreground transition-colors" />
                </a>
                <a
                  href="https://twitter.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-12 h-12 rounded-xl bg-foreground/5 border border-foreground/10 flex items-center justify-center hover:border-foreground/20 hover:bg-foreground/10 transition-all group"
                >
                  <Share2 className="w-5 h-5 text-foreground group-hover:text-foreground transition-colors" />
                </a>
              </div>
            </div>

            {/* CTA Button */}
            <a
              href="mailto:subham@example.com"
              className="inline-flex items-center gap-3 px-8 py-4 bg-foreground text-background font-medium rounded-lg hover:bg-foreground/90 transition-all group"
            >
              Send Me An Email
            </a>
          </div>
        </div>

        {/* Footer */}
        <div className="mt-20 pt-12 border-t border-foreground/10 flex flex-col md:flex-row items-center justify-between gap-8">
          <p className="text-sm text-foreground/60">
            © 2024 Subham Santra. All rights reserved.
          </p>
          <div className="flex gap-6">
            <a href="#" className="text-sm text-foreground/60 hover:text-foreground transition-colors">
              Privacy
            </a>
            <a href="#" className="text-sm text-foreground/60 hover:text-foreground transition-colors">
              Terms
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
