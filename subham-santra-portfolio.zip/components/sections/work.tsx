'use client';

import Image from 'next/image';
import { ArrowUpRight } from 'lucide-react';
import { useState } from 'react';

const projects = [
  {
    id: 1,
    title: 'Modern E-Commerce Platform',
    description: 'Full-stack e-commerce solution with real-time inventory and payment integration',
    image: 'https://images.unsplash.com/photo-1460925895917-aae19106c1e2?w=800&h=600&fit=crop',
    tags: ['React', 'Next.js', 'Stripe', 'PostgreSQL'],
    link: '#',
    category: 'E-Commerce',
  },
  {
    id: 2,
    title: 'Analytics Dashboard',
    description: 'Real-time analytics platform with interactive visualizations and data insights',
    image: 'https://images.unsplash.com/photo-1504384308090-c894fdcc538d?w=800&h=600&fit=crop',
    tags: ['React', 'TypeScript', 'D3.js', 'Node.js'],
    link: '#',
    category: 'Dashboard',
  },
  {
    id: 3,
    title: 'Collaboration App',
    description: 'Team collaboration tool with real-time updates and file sharing capabilities',
    image: 'https://images.unsplash.com/photo-1552664730-d307ca884978?w=800&h=600&fit=crop',
    tags: ['Next.js', 'WebSockets', 'MongoDB', 'AWS'],
    link: '#',
    category: 'SaaS',
  },
];

export function WorkSection() {
  const [hoveredProject, setHoveredProject] = useState<number | null>(null);

  return (
    <section id="work" className="py-24 md:py-32 relative overflow-hidden">
      {/* Animated background */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-white/5 rounded-full blur-3xl -z-10"></div>

      <div className="max-w-7xl mx-auto px-6 md:px-8">
        {/* Header */}
        <div className="mb-20 space-y-4">
          <p className="text-sm font-medium text-foreground/60 uppercase tracking-widest">Portfolio</p>
          <h2 className="text-5xl md:text-6xl font-bold tracking-tight">
            Selected <span className="text-foreground/60">Projects</span>
          </h2>
        </div>

        {/* Projects Grid - Card Style */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {projects.map((project, idx) => (
            <div
              key={project.id}
              onMouseEnter={() => setHoveredProject(project.id)}
              onMouseLeave={() => setHoveredProject(null)}
              className={`group relative overflow-hidden rounded-2xl transition-all duration-500 cursor-pointer
                ${hoveredProject === project.id ? 'lg:col-span-2 lg:row-span-2' : 'lg:col-span-1'}
              `}
              style={{
                animation: `float-up 0.6s ease-out ${idx * 0.1}s both`,
              }}
            >
              {/* Card Background */}
              <div className="absolute inset-0 bg-gradient-to-br from-white/10 to-white/5 rounded-2xl transition-all duration-300"></div>

              {/* Image */}
              <div className="relative w-full h-64 md:h-96 overflow-hidden">
                <Image
                  src={project.image}
                  alt={project.title}
                  fill
                  className="object-cover transition-transform duration-700 group-hover:scale-110"
                />
                {/* Overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-background via-background/40 to-transparent opacity-70 group-hover:opacity-50 transition-opacity duration-300"></div>
              </div>

              {/* Content Overlay */}
              <div className={`absolute inset-0 p-6 md:p-8 flex flex-col justify-between transition-all duration-300
                ${hoveredProject === project.id ? 'opacity-100' : 'opacity-0 md:opacity-100'}
              `}>
                {/* Category Badge */}
                <div className="flex justify-between items-start">
                  <span className="inline-block px-3 py-1 bg-white/10 backdrop-blur-sm rounded-full text-xs font-medium text-white/80 border border-white/20">
                    {project.category}
                  </span>
                  <div className="opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <ArrowUpRight className="w-5 h-5 text-white" />
                  </div>
                </div>

                {/* Bottom Content */}
                <div className="space-y-4">
                  {/* Title */}
                  <div>
                    <h3 className="text-xl md:text-2xl font-bold text-white mb-2 line-clamp-2">
                      {project.title}
                    </h3>
                    <p className={`text-white/70 text-sm md:text-base leading-relaxed transition-all duration-300
                      ${hoveredProject === project.id ? 'line-clamp-3 opacity-100' : 'line-clamp-2 md:line-clamp-3'}
                    `}>
                      {project.description}
                    </p>
                  </div>

                  {/* Tags */}
                  <div className={`flex flex-wrap gap-2 transition-all duration-300
                    ${hoveredProject === project.id ? 'opacity-100' : 'opacity-0 md:opacity-100'}
                  `}>
                    {project.tags.map((tag) => (
                      <span
                        key={tag}
                        className="px-2 md:px-3 py-1 bg-white/10 backdrop-blur-sm text-white/70 text-xs font-medium rounded-lg border border-white/20"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>

                  {/* Link */}
                  <a
                    href={project.link}
                    className="inline-flex items-center gap-2 text-white font-medium text-sm md:text-base hover:gap-3 transition-all opacity-0 group-hover:opacity-100 duration-300"
                  >
                    Explore Project
                    <ArrowUpRight className="w-4 h-4" />
                  </a>
                </div>
              </div>

              {/* Border glow on hover */}
              <div className={`absolute inset-0 rounded-2xl border-2 pointer-events-none transition-all duration-300
                ${hoveredProject === project.id ? 'border-white/30 shadow-lg shadow-white/10' : 'border-white/10'}
              `}></div>
            </div>
          ))}
        </div>

        {/* View All CTA */}
        <div className="mt-16 text-center">
          <a
            href="#"
            className="inline-flex items-center gap-3 px-8 py-4 bg-foreground text-background font-medium rounded-lg hover:bg-foreground/90 transition-all group"
          >
            View All Projects
            <ArrowUpRight className="w-4 h-4 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
          </a>
        </div>
      </div>
    </section>
  );
}
