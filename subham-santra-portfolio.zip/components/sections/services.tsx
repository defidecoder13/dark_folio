'use client';

import { Code2, Zap, Eye } from 'lucide-react';

const services = [
  {
    icon: Code2,
    title: 'Full Stack Development',
    description: 'Custom web applications built with modern technologies like React, Next.js, and Node.js. From concept to deployment.',
  },
  {
    icon: Zap,
    title: 'Performance Optimization',
    description: 'Ensuring your applications run smoothly and efficiently. Optimized for speed, accessibility, and SEO.',
  },
  {
    icon: Eye,
    title: 'UI/UX Implementation',
    description: 'Transforming designs into pixel-perfect, interactive web experiences that users love.',
  },
];

export function ServicesSection() {
  return (
    <section id="services" className="py-20 md:py-32 border-t border-foreground/5">
      <div className="max-w-7xl mx-auto px-6 md:px-8">
        {/* Header */}
        <div className="mb-16">
          <p className="text-sm font-medium text-foreground/60 uppercase tracking-wider mb-4">Services</p>
          <h2 className="text-4xl md:text-5xl font-bold leading-tight">
            What I Offer
          </h2>
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {services.map((service, idx) => {
            const Icon = service.icon;
            return (
              <div
                key={idx}
                className="group p-8 rounded-2xl border border-foreground/10 hover:border-foreground/20 bg-foreground/[0.02] hover:bg-foreground/5 transition-all"
              >
                <div className="mb-6">
                  <div className="w-12 h-12 rounded-xl bg-foreground/10 group-hover:bg-foreground/15 flex items-center justify-center transition-colors">
                    <Icon className="w-6 h-6 text-foreground" />
                  </div>
                </div>
                <h3 className="text-xl font-bold mb-3">{service.title}</h3>
                <p className="text-foreground/70 leading-relaxed">{service.description}</p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
