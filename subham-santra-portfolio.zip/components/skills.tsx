"use client";

import { useState } from "react";

export function Skills() {
  const [activeCategory, setActiveCategory] = useState(0);

  const skillsData = [
    {
      category: "Frontend",
      skills: ["React", "Next.js", "TypeScript", "Tailwind CSS", "Framer Motion", "Redux", "Zustand", "Vue.js"]
    },
    {
      category: "Backend",
      skills: ["Node.js", "Express.js", "PostgreSQL", "MongoDB", "Redis", "GraphQL", "REST APIs", "Socket.io"]
    },
    {
      category: "Tools & DevOps",
      skills: ["Git", "Docker", "AWS", "Vercel", "CI/CD", "GitHub Actions", "Webpack", "Vite"]
    },
    {
      category: "Design & UX",
      skills: ["Figma", "UI/UX Design", "Responsive Design", "Accessibility", "Design Systems", "Prototyping", "Wireframing", "Animation"]
    }
  ];

  return (
    <section id="skills" className="py-20 md:py-32 relative overflow-hidden">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 right-0 w-96 h-96 bg-accent/5 rounded-full blur-3xl"></div>
      </div>

      <div className="container max-w-7xl mx-auto px-4 md:px-6 relative z-10">
        {/* Section Header */}
        <div className="mb-16 md:mb-24">
          <div className="inline-block mb-4">
            <span className="px-4 py-2 bg-primary/10 text-primary border border-primary/30 rounded-full text-sm font-semibold">Technical Skills</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
            A Diverse Toolkit
          </h2>
          <p className="text-lg text-foreground/70 max-w-2xl">
            Built through hands-on experience and continuous learning across the full stack
          </p>
        </div>

        {/* Skills Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 md:gap-12">
          {/* Category Navigation */}
          <div className="flex flex-col gap-6">
            {skillsData.map((category, idx) => (
              <button
                key={idx}
                onClick={() => setActiveCategory(idx)}
                className={`group relative text-left p-6 rounded-xl border-2 transition-all duration-300 transform hover:scale-105 ${
                  activeCategory === idx
                    ? "border-primary bg-surface/70 shadow-lg shadow-primary/20"
                    : "border-primary/20 bg-surface/40 hover:border-primary/40 hover:bg-surface/50"
                }`}
              >
                <div className="flex items-center justify-between">
                  <h3 className={`text-lg font-bold transition-colors ${
                    activeCategory === idx ? "text-primary" : "text-foreground group-hover:text-primary"
                  }`}>
                    {category.category}
                  </h3>
                  <span className={`text-lg transition-transform ${activeCategory === idx ? "text-primary" : "text-muted"}`}>
                    {activeCategory === idx ? "→" : "+"}
                  </span>
                </div>
                <p className="text-sm text-foreground/60 mt-2">{category.skills.length} skills</p>
              </button>
            ))}
          </div>

          {/* Skills Display */}
          <div className="relative">
            <div className="bg-gradient-to-br from-surface/60 to-surface/40 backdrop-blur-md border border-primary/20 rounded-xl p-8 min-h-96 flex items-center justify-center">
              {/* Active skills grid */}
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4 w-full">
                {skillsData[activeCategory].skills.map((skill, idx) => (
                  <div
                    key={idx}
                    className="group relative"
                    style={{
                      animation: `fadeIn 0.3s ease-out ${idx * 0.05}s both`
                    }}
                  >
                    <div className="absolute inset-0 bg-gradient-to-r from-primary/30 to-secondary/30 rounded-lg blur opacity-0 group-hover:opacity-100 transition-opacity"></div>
                    <div className="relative bg-surface/70 backdrop-blur-sm border border-primary/40 rounded-lg p-4 text-center hover:border-primary/80 hover:bg-surface/90 transition-all transform group-hover:scale-110">
                      <span className="text-foreground font-semibold text-sm md:text-base">{skill}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Skill meter placeholder */}
            <div className="mt-8 space-y-4">
              {[
                { name: "Expertise", value: 95 },
                { name: "Problem Solving", value: 90 },
                { name: "Communication", value: 85 }
              ].map((skill) => (
                <div key={skill.name} className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted">{skill.name}</span>
                    <span className="text-sm font-semibold text-primary">{skill.value}%</span>
                  </div>
                  <div className="h-2 bg-surface/40 rounded-full overflow-hidden border border-primary/10">
                    <div
                      className="h-full bg-gradient-to-r from-primary to-secondary rounded-full transition-all duration-1000"
                      style={{ width: `${skill.value}%` }}
                    ></div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      <style jsx>{`
        @keyframes fadeIn {
          from {
            opacity: 0;
            transform: translateY(10px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
      `}</style>
    </section>
  );
}
