import { ExternalLink, GitBranch } from "lucide-react";

export function Projects() {
  const projects = [
    {
      title: "E-Commerce Platform",
      description: "A modern full-stack e-commerce solution with real-time inventory, payment processing, and admin dashboard.",
      tags: ["Next.js", "TypeScript", "Stripe", "PostgreSQL"],
      image: "https://images.unsplash.com/photo-1460925895917-aeb19be489c7?w=800&h=400&fit=crop",
      link: "#",
      github: "#"
    },
    {
      title: "SaaS Analytics Dashboard",
      description: "Interactive dashboard for real-time data visualization, user analytics, and business intelligence.",
      tags: ["React", "D3.js", "Node.js", "MongoDB"],
      image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=800&h=400&fit=crop",
      link: "#",
      github: "#"
    },
    {
      title: "AI Chat Application",
      description: "AI-powered chat application with natural language processing and machine learning integration.",
      tags: ["Next.js", "OpenAI API", "Redis", "WebSocket"],
      image: "https://images.unsplash.com/photo-1677442d019cecf8d56b2a1df4468b5ce3c27971?w=800&h=400&fit=crop",
      link: "#",
      github: "#"
    },
    {
      title: "Real Estate Platform",
      description: "Full-featured property listing platform with advanced search, virtual tours, and booking system.",
      tags: ["React", "Firebase", "Google Maps", "Tailwind CSS"],
      image: "https://images.unsplash.com/photo-1552321554-5fefe8c9ef14?w=800&h=400&fit=crop",
      link: "#",
      github: "#"
    },
    {
      title: "Social Media App",
      description: "Social networking platform with real-time messaging, notifications, and content sharing.",
      tags: ["Next.js", "Socket.io", "PostgreSQL", "Redis"],
      image: "https://images.unsplash.com/photo-1611532736597-de2d4265fba3?w=800&h=400&fit=crop",
      link: "#",
      github: "#"
    },
    {
      title: "Project Management Tool",
      description: "Collaborative project management with team collaboration, task tracking, and timeline visualization.",
      tags: ["Vue.js", "Express.js", "MongoDB", "WebSocket"],
      image: "https://images.unsplash.com/photo-1552664730-d307ca884978?w=800&h=400&fit=crop",
      link: "#",
      github: "#"
    }
  ];

  return (
    <section id="projects" className="py-20 md:py-32 relative overflow-hidden">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-secondary/5 rounded-full blur-3xl"></div>
      </div>

      <div className="container max-w-7xl mx-auto px-4 md:px-6 relative z-10">
        {/* Section Header */}
        <div className="mb-16 md:mb-24">
          <div className="inline-block mb-4">
            <span className="px-4 py-2 bg-primary/10 text-primary border border-primary/30 rounded-full text-sm font-semibold">Featured Projects</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
            My Best Work
          </h2>
          <p className="text-lg text-foreground/70 max-w-2xl">
            A selection of projects that showcase my expertise in full-stack development and innovative problem-solving
          </p>
        </div>

        {/* Projects Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project, idx) => (
            <div
              key={idx}
              className="group relative bg-surface/50 backdrop-blur-md border border-primary/20 rounded-xl overflow-hidden hover:border-primary/60 transition-all hover:shadow-2xl hover:shadow-primary/15 transform hover:scale-105"
            >
              {/* Image Container */}
              <div className="relative h-52 overflow-hidden bg-surface">
                <img
                  src={project.image}
                  alt={project.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-background via-background/40 to-transparent opacity-70"></div>
              </div>

              {/* Content */}
              <div className="p-6 space-y-4">
                <h3 className="text-lg font-bold text-foreground group-hover:text-primary transition-colors duration-300">
                  {project.title}
                </h3>
                <p className="text-foreground/70 text-sm leading-relaxed line-clamp-2">{project.description}</p>

                {/* Tags */}
                <div className="flex flex-wrap gap-2">
                  {project.tags.map((tag) => (
                    <span
                      key={tag}
                      className="px-3 py-1 bg-primary/15 text-primary text-xs font-medium rounded-full border border-primary/30 group-hover:border-primary/60 group-hover:bg-primary/25 transition-all"
                    >
                      {tag}
                    </span>
                  ))}
                </div>

                {/* Links */}
                <div className="flex gap-3 pt-2">
                  <a
                    href={project.link}
                    className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 bg-primary text-background font-semibold rounded-lg hover:shadow-lg hover:shadow-primary/50 transition-all text-sm group/btn hover:bg-primary/90"
                  >
                    <ExternalLink className="w-4 h-4" />
                    Visit
                  </a>
                  <a
                    href={project.github}
                    className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 border-2 border-primary/40 text-primary rounded-lg hover:border-primary hover:bg-primary/10 transition-all text-sm group/btn font-semibold"
                  >
                    <GitBranch className="w-4 h-4" />
                    Code
                  </a>
                </div>
              </div>

              {/* Gradient overlay on hover */}
              <div className="absolute inset-0 bg-gradient-to-br from-primary/0 to-secondary/0 group-hover:from-primary/10 group-hover:to-secondary/10 pointer-events-none transition-all"></div>
            </div>
          ))}
        </div>

        {/* View More Button */}
        <div className="text-center mt-16">
          <button className="group relative px-8 py-3 bg-gradient-to-r from-primary to-secondary text-background font-semibold rounded-lg overflow-hidden hover:shadow-lg hover:shadow-primary/50 transition-all">
            <span className="relative z-10 flex items-center gap-2 justify-center">
              View All Projects
              <ExternalLink className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </span>
          </button>
        </div>
      </div>
    </section>
  );
}
