"use client";

import { Mail, MapPin, Phone, Send } from "lucide-react";
import { useState } from "react";

export function Contact() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: ""
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState<"idle" | "success" | "error">("idle");

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate API call
    setTimeout(() => {
      setSubmitStatus("success");
      setFormData({ name: "", email: "", message: "" });
      setIsSubmitting(false);
      
      setTimeout(() => setSubmitStatus("idle"), 3000);
    }, 1000);
  };

  const contactInfo = [
    {
      icon: Mail,
      label: "Email",
      value: "subham@example.com",
      href: "mailto:subham@example.com"
    },
    {
      icon: Phone,
      label: "Phone",
      value: "+1 (555) 123-4567",
      href: "tel:+15551234567"
    },
    {
      icon: MapPin,
      label: "Location",
      value: "San Francisco, CA",
      href: "#"
    }
  ];

  return (
    <section id="contact" className="py-20 md:py-32 relative overflow-hidden">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 left-0 w-96 h-96 bg-accent/5 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-primary/5 rounded-full blur-3xl"></div>
      </div>

      <div className="max-w-6xl mx-auto px-6 md:px-8 relative z-10">
        {/* Section Header */}
        <div className="mb-16 md:mb-24">
          <div className="inline-block mb-4">
            <span className="px-4 py-2 bg-primary/10 text-primary border border-primary/30 rounded-full text-sm font-semibold">Get In Touch</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
            Let&apos;s Work Together
          </h2>
          <p className="text-lg text-foreground/70 max-w-2xl">
            Have a project in mind or want to discuss opportunities? I&apos;d love to hear from you. Let&apos;s create something amazing together.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 md:gap-16">
          {/* Contact Info */}
          <div className="space-y-8">
            <div>
              <h3 className="text-2xl font-bold text-foreground mb-6">Get In Touch</h3>
              <p className="text-muted/80 leading-relaxed mb-8">
                Whether you have a question about projects, pricing, or anything else, feel free to reach out. I&apos;m always happy to discuss new opportunities.
              </p>
            </div>

            {/* Contact Cards */}
            <div className="space-y-4">
              {contactInfo.map((info, idx) => {
                const Icon = info.icon;
                return (
                  <a
                    key={idx}
                    href={info.href}
                    className="group flex items-start gap-4 p-6 rounded-xl bg-surface/50 backdrop-blur-md border border-primary/20 hover:border-primary/60 hover:bg-surface/70 transition-all transform hover:translate-x-2"
                  >
                    <div className="p-3 bg-primary/10 rounded-lg group-hover:bg-primary/20 transition-colors flex-shrink-0">
                      <Icon className="w-6 h-6 text-primary" />
                    </div>
                    <div>
                      <p className="text-xs text-primary font-bold uppercase tracking-wider">{info.label}</p>
                      <p className="text-foreground font-semibold mt-2 group-hover:text-primary transition-colors">{info.value}</p>
                    </div>
                  </a>
                );
              })}
            </div>

            {/* Social Links */}
            <div className="pt-8 border-t border-primary/10">
              <h4 className="text-sm font-semibold text-muted uppercase tracking-wider mb-4">Follow Me</h4>
              <div className="flex gap-4">
                {[
                  { name: "GitHub", url: "#" },
                  { name: "LinkedIn", url: "#" },
                  { name: "Twitter", url: "#" },
                  { name: "Discord", url: "#" }
                ].map((social) => (
                  <a
                    key={social.name}
                    href={social.url}
                    className="w-10 h-10 rounded-lg border border-primary/30 flex items-center justify-center text-muted hover:text-primary hover:border-primary hover:bg-primary/10 transition-all text-xs font-bold"
                    aria-label={social.name}
                  >
                    {social.name[0]}
                  </a>
                ))}
              </div>
            </div>
          </div>

          {/* Contact Form */}
          <div className="relative group">
            <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-secondary/20 rounded-xl blur-xl group-hover:blur-2xl transition-all opacity-50 group-hover:opacity-70"></div>
            
            <form
              onSubmit={handleSubmit}
              className="relative bg-surface/80 backdrop-blur-sm border border-primary/30 rounded-xl p-8 space-y-6"
            >
              <div>
                <label htmlFor="name" className="block text-sm font-semibold text-foreground mb-2">
                  Your Name
                </label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-3 bg-surface/60 border border-primary/20 rounded-lg text-foreground placeholder-muted/50 focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/20 transition-all"
                  placeholder="John Doe"
                />
              </div>

              <div>
                <label htmlFor="email" className="block text-sm font-semibold text-foreground mb-2">
                  Email Address
                </label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-3 bg-surface/60 border border-primary/20 rounded-lg text-foreground placeholder-muted/50 focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/20 transition-all"
                  placeholder="john@example.com"
                />
              </div>

              <div>
                <label htmlFor="message" className="block text-sm font-semibold text-foreground mb-2">
                  Message
                </label>
                <textarea
                  id="message"
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  required
                  rows={5}
                  className="w-full px-4 py-3 bg-surface/60 border border-primary/20 rounded-lg text-foreground placeholder-muted/50 focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/20 transition-all resize-none"
                  placeholder="Your message here..."
                ></textarea>
              </div>

              {/* Submit Status */}
              {submitStatus === "success" && (
                <div className="p-3 bg-success/10 border border-success text-success text-sm rounded-lg">
                  ✓ Message sent successfully! I&apos;ll get back to you soon.
                </div>
              )}

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full group/btn relative px-6 py-3 bg-gradient-to-r from-primary to-primary/80 text-background font-semibold rounded-lg overflow-hidden hover:shadow-lg hover:shadow-primary/50 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              >
                <span className="relative z-10">
                  {isSubmitting ? "Sending..." : "Send Message"}
                </span>
                <Send className="w-4 h-4 group-hover/btn:translate-x-1 transition-transform" />
                <div className="absolute inset-0 bg-gradient-to-r from-primary/60 to-secondary/60 opacity-0 group-hover/btn:opacity-100 transition-opacity"></div>
              </button>

              {/* Glow effect */}
              <div className="absolute inset-0 bg-gradient-to-r from-primary/0 via-primary/10 to-secondary/0 opacity-0 group-hover:opacity-100 rounded-xl transition-opacity pointer-events-none"></div>
            </form>
          </div>
        </div>

        {/* Footer */}
        <div className="mt-20 pt-12 border-t border-primary/10 text-center">
          <p className="text-muted/70">
            © 2024 Subham Santra. All rights reserved. Built with Next.js & Tailwind CSS.
          </p>
        </div>
      </div>
    </section>
  );
}
