import { HeroSection } from "@/components/sections/hero";
import { AboutSection } from "@/components/sections/about";
import { SkillsSection } from "@/components/sections/skills";
import { WorkSection } from "@/components/sections/work";
import { ServicesSection } from "@/components/sections/services";
import { ContactSection } from "@/components/sections/contact";
import { Header } from "@/components/layout/header";

export const metadata = {
  title: "Subham Santra — Full Stack Developer",
  description: "Creating beautiful digital experiences with modern web technologies.",
};

export default function Home() {
  return (
    <main className="w-full">
      <Header />
      <HeroSection />
      <AboutSection />
      <SkillsSection />
      <WorkSection />
      <ServicesSection />
      <ContactSection />
    </main>
  );
}
